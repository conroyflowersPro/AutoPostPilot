자르는 규칙
- ## V1 부터 다음 ## 직전까지 = 파일 하나
- 맨 위 안내문은 넣지 않음
- V9 / W9 올리지 않음

업로드
- viral/ V1.md~V8.md  →  Collection 「힘 알아보기」
- writing/ W1.md~W8.md →  Collection 「닫기 형식」

콘솔
1. 예전 viral-theories.md / writing-theories.md 삭제
2. 위 16개만 해당 Collection에 업로드
3. Max chunk 2048, overlap 0, Inject name OFF
4. 임베딩 Ready까지 대기
